DEPLOY TO HEROKU (run inside this folder)

  git init
  git add .
  git commit -m "Portfolio"
  heroku login
  heroku create YOUR-APP-NAME
  git push heroku master      (use "main" instead of "master" if your branch is main)
  heroku open

Copy the URL Heroku prints (https://YOUR-APP-NAME-xxxx.herokuapp.com) and submit it.

GITHUB: upload this whole folder to your repo. SVG pages are in /SVG, Canvas page in /Canvas.
